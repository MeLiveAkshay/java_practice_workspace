package assignment.assignment__11.problem__1;

import java.util.HashMap;

public class HashMapProblem {
    public static void main(String[] args) {
        HashMap hashMap=new HashMap<>();
    }
}
